package service;
import models.Obat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class obatService {
    private ArrayList<Obat> daftarObat = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

      public obatService() {
        daftarObat.add(new Obat("Amoxcillin", "Antibiotik",
                LocalDate.parse("01-12-2027", formatter), 120, 5000));
        daftarObat.add(new Obat("Paracetamol", "Analgesik",
                LocalDate.parse("22-03-2028", formatter), 80, 12000));
        daftarObat.add(new Obat("Ibuprofen", "Analgesik",
                LocalDate.parse("28-02-2028", formatter), 50, 8000));
        daftarObat.add(new Obat("Vitamin C", "Suplemen",
                LocalDate.parse("01-01-2026", formatter), 100, 4000));
    }
      
    // Tambah Obat
    public void tambahObat() {
        try {
            System.out.print("Masukkan nama obat: ");
            String nama = scanner.nextLine();
            if (nama.isEmpty()) {
                System.out.println("Nama obat tidak boleh kosong!");
                return;
            }

            System.out.print("Masukkan kategori: ");
            String kategori = scanner.nextLine();

            System.out.print("Masukkan expired date (dd-MM-yyyy): ");
            String expiredInput = scanner.nextLine();
            LocalDate expiredDate = LocalDate.parse(expiredInput, formatter);

            System.out.print("Masukkan stok: ");
            int stok = Integer.parseInt(scanner.nextLine());

            System.out.print("Masukkan harga: ");
            double harga = Double.parseDouble(scanner.nextLine());

            daftarObat.add(new Obat(nama, kategori, expiredDate, stok, harga));
            System.out.println("Obat berhasil ditambahkan!");
        } catch (Exception e) {
            System.out.println("Input tidak valid! Silakan coba lagi.");
        }
    }

    // Tampilkan Daftar Obat
    public void tampilkanObat() {
        if (daftarObat.isEmpty()) {
            System.out.println("Daftar obat kosong.");
        } else {
            System.out.println("\n===== < Daftar Obat > =====");
            for (int i = 0; i < daftarObat.size(); i++) {
                System.out.println((i + 1) + ".");
                daftarObat.get(i).tampilkanObat();
            }
        }
    }

    // Update Obat
    public void updateObat() {
        tampilkanObat();
        if (daftarObat.isEmpty()) return;

        System.out.print("Pilih nomor obat yang ingin diupdate: ");
        int index = Integer.parseInt(scanner.nextLine()) - 1;

        if (index >= 0 && index < daftarObat.size()) {
            Obat o = daftarObat.get(index);

            System.out.print("Nama baru (" + o.getNamaObat() + "): ");
            String namaBaru = scanner.nextLine();
            if (!namaBaru.isEmpty()) o.setNamaObat(namaBaru);

            System.out.print("Kategori baru (" + o.getKategori() + "): ");
            String kategoriBaru = scanner.nextLine();
            if (!kategoriBaru.isEmpty()) o.setKategori(kategoriBaru);

            System.out.print("Stok baru (" + o.getStok() + "): ");
            String stokInput = scanner.nextLine();
            if (!stokInput.isEmpty()) o.setStok(Integer.parseInt(stokInput));

            System.out.print("Harga baru (" + o.getHarga() + "): ");
            String hargaInput = scanner.nextLine();
            if (!hargaInput.isEmpty()) o.setHarga(Double.parseDouble(hargaInput));

            System.out.println("Obat berhasil diupdate!");
        } else {
            System.out.println("Nomor obat tidak valid!");
        }
    }

    // Hapus Obat
    public void hapusObat() {
        tampilkanObat();
        if (daftarObat.isEmpty()) return;

        System.out.print("Pilih nomor obat yang ingin dihapus: ");
        int index = Integer.parseInt(scanner.nextLine()) - 1;

        if (index >= 0 && index < daftarObat.size()) {
            daftarObat.remove(index);
            System.out.println("Obat berhasil dihapus!");
        } else {
            System.out.println("Nomor obat tidak valid!");
        }
    }

    // Search Obat
    public void cariObat() {
        System.out.print("Masukkan nama obat yang ingin dicari: ");
        String keyword = scanner.nextLine().toLowerCase();

        boolean ditemukan = false;
        for (Obat o : daftarObat) {
            if (o.getNamaObat().toLowerCase().contains(keyword)) {
                o.tampilkanObat();
                ditemukan = true;
            }
        }

        if (!ditemukan) {
            System.out.println("Obat dengan kata kunci '" + keyword + "' tidak ditemukan.");
        }
    }
}
